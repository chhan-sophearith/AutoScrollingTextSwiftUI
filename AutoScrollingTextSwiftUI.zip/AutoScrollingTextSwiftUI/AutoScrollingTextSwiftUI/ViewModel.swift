//
//  ViewModel.swift
//  AutoScrollingTextSwiftUI
//
//  Created by Chhan Sophearith on 29/9/23.
//

import Foundation
import SwiftUI

class ViewModel: ObservableObject {
    let array = [
        Info(id: "1", name: "Apple Apple Apple Apple"),
        Info(id: "2", name: "Derzeit ist unser Chat stark ausgelastet. Bitte haben Sie etwas Geduld oder nutzen Sie die Vollbildversion unter"),
        Info(id: "3", name: "Car"),
        Info(id: "4", name: "Derzeit ist unser Chat stark ausgelastet. Bitte haben Sie etwas Geduld oder nutzen Sie die Vollbildversion unter"),
        Info(id: "5", name: "Eyes")
    ]
    
    func getAnnouncementString() -> String {
        var str = ""
        array.forEach({ item in
            str.append(item.name + " ")
        })
        return str.replacingOccurrences(of: "\n", with: "")
    }
}

struct Info {
    let id: String
    let name: String
}

extension String {
    func sizeOf() -> CGSize {
        let font = UIFont(name: "Helvetica", size: 14)
        return self.size(withAttributes: [NSAttributedString.Key.font: font as Any])
    }
}
