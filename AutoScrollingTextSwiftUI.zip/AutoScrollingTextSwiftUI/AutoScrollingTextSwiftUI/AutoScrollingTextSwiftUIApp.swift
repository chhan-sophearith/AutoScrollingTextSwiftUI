//
//  AutoScrollingTextSwiftUIApp.swift
//  AutoScrollingTextSwiftUI
//
//  Created by Chhan Sophearith on 28/9/23.
//

import SwiftUI

@main
struct AutoScrollingTextSwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
