    //
    //  ContentView.swift
    //  AutoScrollingTextSwiftUI
    //
    //  Created by Chhan Sophearith on 28/9/23.
    //

import SwiftUI

struct ContentView: View {
    @StateObject var viewModel = ViewModel()
    @State var scrollText = false
    var zeroPoint: CGFloat = 0
    var screenEntryPoint: CGFloat = UIScreen.main.bounds.width
    @State var textWidth: CGFloat = 0
    
    var body: some View {
        NavigationView {
            HStack {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack {
                        ForEach(0..<viewModel.array.count, id: \.self) { index in
                            Text("\(viewModel.array[index].name)")
                                .background(Color.red)
                                .offset(x: scrollText ? -(textWidth + screenEntryPoint) : screenEntryPoint)
                                .animation(.easeInOut(duration: textWidth / 32).repeatForever(autoreverses: false))
                                .onTapGesture {
                                    print("index-->:", index)
                                }
                        }
                    }
                }
            }
            .onAppear {
                self.scrollText.toggle()
                textWidth = viewModel.getAnnouncementString().sizeOf().width
            }
        }
    }
}

#Preview {
    ContentView()
}
